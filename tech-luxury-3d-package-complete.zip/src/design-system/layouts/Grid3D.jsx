import React from 'react';

const Grid3D = ({ children }) => {
  return <div style={{display:'grid',gridTemplateColumns:'repeat(auto-fit,minmax(240px,1fr))',gap:16}}>{children}</div>;
};

export default Grid3D;
