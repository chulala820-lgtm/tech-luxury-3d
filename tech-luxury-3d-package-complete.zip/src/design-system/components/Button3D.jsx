import React from 'react';
import { colors } from '../design-tokens/colors';

const Button3D = ({ children, variant='primary', size='md', onClick }) => {
  const style = {
    padding: '12px 24px',
    borderRadius: 12,
    background: variant === 'primary' ? 'linear-gradient(135deg,#00B4D8,#00FFFC)' : 'transparent',
    color: variant === 'primary' ? '#000' : '#fff',
    cursor: 'pointer',
    transform: 'translateZ(20px)'
  };
  return <button style={style} onClick={onClick}>{children}</button>;
};

export default Button3D;
