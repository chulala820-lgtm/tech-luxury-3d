import React from 'react';

const DepthSlider = ({ min=0, max=100, value=50, onChange }) => {
  return (
    <input
      type="range"
      min={min}
      max={max}
      value={value}
      onChange={(e)=>onChange && onChange(Number(e.target.value))}
      style={{width:'100%'}}
    />
  );
};

export default DepthSlider;
