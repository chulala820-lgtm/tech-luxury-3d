import React, { useRef, useEffect } from 'react';
import { motion } from 'framer-motion';
import { colors } from '../design-tokens/colors';

const GlassCard = ({ children, className='', depth=25, interactive=true, variant='glass', ...props }) => {
  const cardRef = useRef(null);

  useEffect(()=> {
    if (cardRef.current && interactive) {
      // nothing heavy; keep simple
    }
  }, [interactive]);

  const style = {
    background: 'rgba(255,255,255,0.03)',
    border: '1px solid rgba(255,255,255,0.08)',
    borderRadius: 12,
    padding: 16,
    transform: `translateZ(${depth}px)`,
    position: 'relative'
  };

  return (
    <motion.div ref={cardRef} className={className} style={style} {...props}>
      <div style={{transform:'translateZ(20px)'}}>{children}</div>
      <div style={{position:'absolute',inset:0,borderRadius:12,boxShadow:colors.glow.soft,opacity:0.2}} />
    </motion.div>
  );
};

export default GlassCard;
