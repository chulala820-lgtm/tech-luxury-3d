import React from 'react';

const Icon3D = ({ icon: IconComponent, size=24 }) => {
  return (
    <div style={{width:size,height:size,transform:'translateZ(10px)'}}>
      {IconComponent ? <IconComponent size={size} /> : null}
    </div>
  );
};

export default Icon3D;
