export const colors = {
  primary: { black: '#0A0A0A', charcoal: '#2C3E50' },
  accent: { electricBlue: '#00B4D8', neonCyan: '#00FFFC' },
  luxury: { platinum: '#E5E4E2' },
  gradients: { cyber: 'linear-gradient(135deg, #00B4D8, #00FFFC)' },
  depth: { level1: '10px', level2: '25px' },
  glow: { soft: '0 0 20px rgba(0, 180, 216, 0.3)' }
};
