/**
 * @jest-environment jsdom
 */
describe('XR renderer DOM attach/cleanup behavior (basic simulation)', () => {
  let container;
  let fakeRenderer;

  beforeEach(() => {
    document.body.innerHTML = '';
    container = document.createElement('div');
    container.className = 'xr-viewport';
    document.body.appendChild(container);
    fakeRenderer = { domElement: document.createElement('canvas') };
  });

  afterEach(() => {
    document.body.innerHTML = '';
  });

  test('appends the renderer.domElement only once when called multiple times', () => {
    if (!container.contains(fakeRenderer.domElement)) container.appendChild(fakeRenderer.domElement);
    if (!container.contains(fakeRenderer.domElement)) container.appendChild(fakeRenderer.domElement);
    const canvases = container.getElementsByTagName('canvas');
    expect(canvases.length).toBe(1);
  });

  test('removes renderer.domElement on cleanup (container removed)', () => {
    container.appendChild(fakeRenderer.domElement);
    expect(container.contains(fakeRenderer.domElement)).toBe(true);
    if (fakeRenderer.domElement.parentNode) fakeRenderer.domElement.parentNode.removeChild(fakeRenderer.domElement);
    expect(container.contains(fakeRenderer.domElement)).toBe(false);
  });

  test('no-ops safely when renderer or domElement missing', () => {
    const brokenRenderer = {};
    let threw = false;
    try {
      if (brokenRenderer.domElement && !container.contains(brokenRenderer.domElement)) container.appendChild(brokenRenderer.domElement);
      if (brokenRenderer.domElement && brokenRenderer.domElement.parentNode) brokenRenderer.domElement.parentNode.removeChild(brokenRenderer.domElement);
    } catch (e) {
      threw = true;
    }
    expect(threw).toBe(false);
  });

});
