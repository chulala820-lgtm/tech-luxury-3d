import React, { useRef, useEffect } from 'react';
import * as THREE from 'three';
import { attachRendererToContainer } from '../../../utils/attachRendererToContainer';

const WebXRManager = ({ enable = false }) => {
  const containerRef = useRef(null);
  const rendererRef = useRef(null);
  const cleanupRef = useRef(null);

  useEffect(() => {
    const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true, preserveDrawingBuffer: false });
    renderer.setSize(window.innerWidth, window.innerHeight);
    rendererRef.current = renderer;

    if (containerRef.current) {
      cleanupRef.current = attachRendererToContainer(renderer, containerRef.current);
    }

    return () => {
      if (cleanupRef.current) cleanupRef.current();
      try { renderer.dispose && renderer.dispose(); } catch (e) {}
      rendererRef.current = null;
    };
  }, []);

  useEffect(() => {
    if (containerRef.current && rendererRef.current && !cleanupRef.current) {
      cleanupRef.current = attachRendererToContainer(rendererRef.current, containerRef.current);
    }
  }, [containerRef.current]);

  return <div ref={el => (containerRef.current = el)} className="xr-viewport" style={{width:'100%',height:'100%'}} />;
};

export default WebXRManager;
