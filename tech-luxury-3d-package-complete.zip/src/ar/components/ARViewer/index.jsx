import React from 'react';
import WebXRManager from './WebXRManager';

const ARViewer = () => {
  return (
    <div style={{width:'100%',height:'100%'}}>
      <WebXRManager enable={true} />
      <div style={{position:'absolute',top:10,left:10,zIndex:20,color:'white'}}>AR Viewer (demo)</div>
    </div>
  );
};

export default ARViewer;
