import React, { Suspense, useState } from 'react';
import ThreeScene from './components/ThreeScene/ThreeScene';
import LoadingScreen from './components/UI/LoadingScreen';
import Navigation from './components/UI/Navigation';
import ProductShowcase from './components/Products/ProductShowcase';
import ServiceGallery from './components/Services/ServiceGallery';
import './styles/main.css';

function App() {
  const [activeSection, setActiveSection] = useState('home');
  const [cart, setCart] = useState([]);
  const [services, setServices] = useState([]);

  return (
    <div className="tech-luxury-app">
      <Suspense fallback={<LoadingScreen />}>
        <div className="three-container">
          <ThreeScene activeSection={activeSection} />
        </div>

        <div className="ui-overlay">
          <Navigation
            activeSection={activeSection}
            setActiveSection={setActiveSection}
            cartCount={cart.length}
            serviceCount={services.length}
          />

          {activeSection === 'home' && (
            <div style={{paddingTop: '120px', textAlign: 'center', color: 'white'}}>
              <h1 style={{fontSize: '48px'}}>TechnoLuxury 3D - Demo</h1>
              <p>Use navigation to explore sections.</p>
            </div>
          )}

          {activeSection === 'products' && (
            <ProductShowcase cart={cart} setCart={setCart} />
          )}

          {activeSection === 'services' && (
            <ServiceGallery services={services} setServices={setServices} />
          )}
        </div>
      </Suspense>
    </div>
  );
}

export default App;
