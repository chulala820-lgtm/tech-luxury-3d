export const hologramShader = `
// Hologram fragment shader (converted to JS string)
#ifdef GL_ES
precision mediump float;
#endif

uniform float time;
uniform vec3 color;
uniform float opacity;
varying vec2 vUv;
varying vec3 vNormal;
varying vec3 vPosition;

float hash(float n) { return fract(sin(n) * 43758.5453123); }
float noise(vec2 x) {
  vec2 p = floor(x);
  vec2 f = fract(x);
  float a = hash(p.x + p.y * 57.0);
  float b = hash(p.x + 1.0 + p.y * 57.0);
  float c = hash(p.x + (p.y + 1.0) * 57.0);
  float d = hash(p.x + 1.0 + (p.y + 1.0) * 57.0);
  vec2 u = f * f * (3.0 - 2.0 * f);
  return mix(a, b, u.x) + (c - a) * u.y * (1.0 - u.x) + (d - b) * u.x * u.y;
}

void main() {
  vec3 baseColor = color;
  float scanLine = sin(vPosition.y * 10.0 + time * 2.0) * 0.5 + 0.5;
  baseColor *= scanLine * 0.3 + 0.7;
  float n = noise(vUv * 3.0 + time * 0.5);
  baseColor += n * 0.05;
  float edge = 1.0 - dot(normalize(vNormal), vec3(0.0, 0.0, 1.0));
  edge = pow(edge, 3.0);
  baseColor += edge * color * 0.5;
  float alpha = opacity * (0.7 + sin(time * 2.0 + vPosition.x * 2.0) * 0.3);
  gl_FragColor = vec4(baseColor, alpha);
}
`;
