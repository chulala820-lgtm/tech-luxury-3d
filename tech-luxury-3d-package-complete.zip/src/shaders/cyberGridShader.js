export const cyberGridShader = `
// Cyber Grid fragment shader (as JS string)
#ifdef GL_ES
precision mediump float;
#endif

uniform float time;
uniform vec3 gridColor;
uniform vec3 glowColor;
uniform float gridSize;
uniform float glowIntensity;
varying vec2 vUv;
varying vec3 vPosition;

void main() {
  vec2 grid = abs(fract(vPosition.xy * gridSize) - 0.5);
  float gridLines = 1.0 - smoothstep(0.0, 0.1, min(grid.x, grid.y));
  float pulse = sin(time * 2.0) * 0.5 + 0.5;
  vec3 glow = glowColor * pulse * glowIntensity;
  float dist = length(vUv - 0.5);
  glow *= 1.0 - dist;
  vec3 color = mix(gridColor, glow, gridLines);
  float scanLine = sin(vPosition.y * 20.0 + time * 5.0) * 0.5 + 0.5;
  color *= scanLine * 0.3 + 0.7;
  gl_FragColor = vec4(color, 1.0);
}
`;
