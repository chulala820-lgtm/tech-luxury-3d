export function attachRendererToContainer(renderer, container) {
  if (!renderer || !renderer.domElement) return () => {};
  const dom = renderer.domElement;
  try {
    if (container && !container.contains(dom)) {
      container.appendChild(dom);
    }
  } catch (err) {
    console.warn('attachRendererToContainer: append failed', err);
  }
  return () => {
    try {
      if (dom && dom.parentNode) dom.parentNode.removeChild(dom);
    } catch (err) {
      console.warn('attachRendererToContainer: remove failed', err);
    }
  };
}
