import { gsap } from 'gsap';

export const animations = {
  entrance: { fadeUp: { initial:{opacity:0,y:40}, animate:{opacity:1,y:0} } },
  hover: { float: { whileHover:{y:-8} } }
};

export function gsapParallax3D(element, options = {}) {
  const { intensity = 0.05, perspective = 1000 } = options;
  if (!element) return () => {};
  gsap.set(element, { transformStyle: 'preserve-3d', perspective });

  const handler = (e) => {
    const x = (e.clientX / window.innerWidth - 0.5) * 2;
    const y = (e.clientY / window.innerHeight - 0.5) * 2;
    gsap.to(element, { duration: 1, rotateY: x * 5, rotateX: y * -5, ease: 'power2.out' });
  };

  window.addEventListener('mousemove', handler);

  return () => {
    window.removeEventListener('mousemove', handler);
  };
}
