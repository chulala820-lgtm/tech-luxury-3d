import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { ShoppingCart } from 'lucide-react';

const products = [
  { id:1, name:'UltraPhone X Pro', category:'Smartphone', price:1299, specs:['6.7" OLED','Snapdragon 8 Gen 3'], color:'#2C3E50', timeline:'1-2 days' },
  { id:2, name:'Quantum Laptop Pro', category:'Laptop', price:2499, specs:['M3 Max','32GB RAM'], color:'#E5E4E2', timeline:'3-5 days' }
];

const ProductShowcase = ({ cart, setCart }) => {
  const [selectedProduct, setSelectedProduct] = useState(null);
  const [config, setConfig] = useState({});

  const handleAddToCart = (product) => setCart([...cart, { ...product, config: config[product.id] || {} }]);
  return (
    <motion.div className="product-showcase" style={{pointerEvents:'auto'}}>
      <div className="showcase-header">
        <h2 className="section-title">Premium Electronics Gallery</h2>
        <div className="cart-indicator">
          <ShoppingCart />
          <span className="cart-count">{cart.length}</span>
        </div>
      </div>

      <div className="products-grid">
        {products.map(product => (
          <motion.div key={product.id} className="product-card-3d" whileHover={{y:-10}}>
            <div style={{height:120, borderRadius:12, background:product.color+'20'}} />
            <div style={{paddingTop:12}}>
              <h3 style={{margin:0}}>{product.name}</h3>
              <div style={{display:'flex',justifyContent:'space-between',alignItems:'center'}}>
                <div>${product.price}</div>
                <button onClick={()=>handleAddToCart(product)} className="add-to-cart-btn">Add to Cart</button>
              </div>
            </div>
          </motion.div>
        ))}
      </div>
    </motion.div>
  );
};

export default ProductShowcase;
