import React from 'react';
import { Home, ShoppingBag, Wrench, BarChart3, Menu } from 'lucide-react';

const Navigation = ({ activeSection, setActiveSection, cartCount, serviceCount }) => {
  const navItems = [
    { id: 'home', label: 'Home', icon: Home, count: 0 },
    { id: 'products', label: 'Products', icon: ShoppingBag, count: cartCount },
    { id: 'services', label: 'Services', icon: Wrench, count: serviceCount },
    { id: 'dashboard', label: 'Dashboard', icon: BarChart3, count: 0 },
  ];

  return (
    <nav className="main-navigation" style={{pointerEvents:'auto'}}>
      <div style={{display:'flex',alignItems:'center',gap:'1rem'}}>
        <div className="brand-logo">TL</div>
        <div className="brand-name">TechnoLuxury</div>
      </div>

      <div style={{display:'flex',gap:'0.75rem'}}>
        {navItems.map(item => {
          const Icon = item.icon;
          return (
            <button key={item.id} onClick={() => setActiveSection(item.id)} className={activeSection===item.id ? 'nav-item active' : 'nav-item'}>
              <Icon />
              <span style={{marginLeft:'6px'}}>{item.label}</span>
              {item.count > 0 && <span className="nav-count">{item.count}</span>}
            </button>
          );
        })}
      </div>

      <button style={{marginLeft:'auto'}} aria-label="menu"><Menu /></button>
    </nav>
  );
};

export default Navigation;
