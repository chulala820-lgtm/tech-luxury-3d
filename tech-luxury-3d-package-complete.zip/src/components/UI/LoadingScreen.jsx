import React from 'react';

const LoadingScreen = () => (
  <div className="loading-screen">
    <div className="loading-spinner" />
    <div>Loading Three.js scene...</div>
  </div>
);

export default LoadingScreen;
