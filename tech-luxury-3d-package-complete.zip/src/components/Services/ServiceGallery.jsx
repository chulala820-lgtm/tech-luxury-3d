import React from 'react';
import { motion } from 'framer-motion';

const services = [
  { id:1, name:'Full-Stack Web Development', timelines:[{days:7,price:1299}], color:'#00B4D8' },
  { id:2, name:'AI & Machine Learning', timelines:[{days:14,price:2499}], color:'#4ECDC4' }
];

const ServiceGallery = ({ services: userServices, setServices }) => {
  const handleOrderService = (service) => {
    const newService = {...service, selectedTimeline: service.timelines[0], orderDate: new Date().toISOString(), status:'pending'};
    setServices([...(userServices||[]), newService]);
  };

  return (
    <motion.div className="service-gallery" style={{pointerEvents:'auto'}}>
      <h2 className="section-title">Digital Services Marketplace</h2>
      <div className="services-grid">
        {services.map(service => (
          <div key={service.id} className="service-card" style={{borderLeft:`4px solid ${service.color}`}}>
            <h3>{service.name}</h3>
            <p>{service.timelines[0].price} USD</p>
            <button onClick={()=>handleOrderService(service)}>Order Service</button>
          </div>
        ))}
      </div>
    </motion.div>
  );
};

export default ServiceGallery;
