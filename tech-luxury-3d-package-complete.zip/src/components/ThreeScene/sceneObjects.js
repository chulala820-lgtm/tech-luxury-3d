import * as THREE from 'three';

export const createFloatingProducts = (scene) => {
  const products = [];

  const phoneGeometry = new THREE.BoxGeometry(1.5, 3, 0.2);
  const phoneMaterial = new THREE.MeshPhysicalMaterial({
    color: 0x2c3e50,
    metalness: 0.9,
    roughness: 0.1,
    clearcoat: 1.0,
    clearcoatRoughness: 0.05,
    emissive: 0x00b4d8,
    emissiveIntensity: 0.2
  });

  const phone = new THREE.Mesh(phoneGeometry, phoneMaterial);
  phone.position.set(-8, 2, 0);
  phone.castShadow = true;
  scene.add(phone);
  products.push(phone);

  const laptopBase = new THREE.BoxGeometry(4, 0.2, 3);
  const laptopScreen = new THREE.BoxGeometry(3.8, 2.5, 0.1);

  const laptop = new THREE.Group();
  const base = new THREE.Mesh(laptopBase, phoneMaterial);
  const screen = new THREE.Mesh(laptopScreen, phoneMaterial);
  screen.position.y = 1.2;
  screen.rotation.x = -Math.PI / 4;

  laptop.add(base, screen);
  laptop.position.set(0, 2, 0);
  scene.add(laptop);
  products.push(laptop);

  const tvGeometry = new THREE.BoxGeometry(8, 4.5, 0.2);
  const tvScreenMaterial = new THREE.MeshPhysicalMaterial({
    color: 0x000000,
    emissive: 0xffffff,
    emissiveIntensity: 0.3,
    metalness: 0.8,
    roughness: 0.2
  });

  const tv = new THREE.Mesh(tvGeometry, tvScreenMaterial);
  tv.position.set(8, 3, 0);
  scene.add(tv);
  products.push(tv);

  products.forEach((product, index) => {
    const ringGeometry = new THREE.TorusGeometry(3 + index, 0.05, 16, 100);
    const ringMaterial = new THREE.MeshBasicMaterial({
      color: 0x00fffc,
      transparent: true,
      opacity: 0.3
    });

    const ring = new THREE.Mesh(ringGeometry, ringMaterial);
    ring.position.copy(product.position);
    ring.rotation.x = Math.PI / 2;
    scene.add(ring);
  });

  return products;
};

export const createServiceOrbs = (scene) => {
  const services = [
    { color: 0x00b4d8, position: [-5, 0, -5], name: 'Web Dev' },
    { color: 0x4ecdc4, position: [5, 0, -5], name: 'AI Services' },
    { color: 0xff6b6b, position: [0, 5, -5], name: 'Photo Editing' },
    { color: 0xffe66d, position: [0, -5, -5], name: 'IT Support' }
  ];

  const orbs = [];

  services.forEach((service) => {
    const geometry = new THREE.SphereGeometry(1, 32, 32);
    const material = new THREE.MeshPhysicalMaterial({
      color: service.color,
      metalness: 0.7,
      roughness: 0.2,
      transmission: 0.9,
      opacity: 0.7,
      transparent: true,
      side: THREE.DoubleSide
    });

    const orb = new THREE.Mesh(geometry, material);
    orb.position.set(...service.position);
    orb.userData = { type: 'service', name: service.name };

    scene.add(orb);
    orbs.push(orb);
  });

  return orbs;
};

export const createBrandAvatar = (scene) => {
  const group = new THREE.Group();

  const headGeometry = new THREE.SphereGeometry(1, 32, 32);
  const headMaterial = new THREE.MeshPhysicalMaterial({
    color: 0x2c3e50,
    metalness: 0.8,
    roughness: 0.2,
    clearcoat: 1.0
  });
  const head = new THREE.Mesh(headGeometry, headMaterial);

  const bodyGeometry = new THREE.ConeGeometry(0.8, 2, 32);
  const bodyMaterial = new THREE.MeshPhysicalMaterial({
    color: 0xe5e4e2,
    metalness: 0.9,
    roughness: 0.1
  });
  const body = new THREE.Mesh(bodyGeometry, bodyMaterial);
  body.position.y = -1.5;

  const armGeometry = new THREE.CylinderGeometry(0.1, 0.1, 1.5);
  const leftArm = new THREE.Mesh(armGeometry, bodyMaterial);
  leftArm.position.set(-1, -0.5, 0);
  leftArm.rotation.z = Math.PI / 4;

  const rightArm = new THREE.Mesh(armGeometry, bodyMaterial);
  rightArm.position.set(1, -0.5, 0);
  rightArm.rotation.z = -Math.PI / 4;

  const auraGeometry = new THREE.SphereGeometry(2, 32, 32);
  const auraMaterial = new THREE.MeshBasicMaterial({
    color: 0x00fffc,
    transparent: true,
    opacity: 0.1,
    side: THREE.DoubleSide
  });
  const aura = new THREE.Mesh(auraGeometry, auraMaterial);

  group.add(head, body, leftArm, rightArm, aura);
  group.position.set(0, 0, -10);
  scene.add(group);

  return group;
};
