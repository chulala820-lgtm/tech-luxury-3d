import React, { useRef, useEffect } from 'react';
import * as THREE from 'three';
import { OrbitControls } from 'three/examples/jsm/controls/OrbitControls';
import { EffectComposer } from 'three/examples/jsm/postprocessing/EffectComposer';
import { RenderPass } from 'three/examples/jsm/postprocessing/RenderPass';
import { UnrealBloomPass } from 'three/examples/jsm/postprocessing/UnrealBloomPass';
import { createFloatingProducts, createServiceOrbs, createBrandAvatar } from './sceneObjects';

const ThreeScene = ({ activeSection }) => {
  const mountRef = useRef(null);
  const sceneRef = useRef(new THREE.Scene());
  const cameraRef = useRef(null);
  const rendererRef = useRef(null);
  const controlsRef = useRef(null);
  const composerRef = useRef(null);
  const animationIdRef = useRef(null);

  useEffect(() => {
    const scene = sceneRef.current;
    const mount = mountRef.current;

    const camera = new THREE.PerspectiveCamera(
      75,
      window.innerWidth / window.innerHeight,
      0.1,
      1000
    );
    camera.position.set(0, 5, 15);
    cameraRef.current = camera;

    const renderer = new THREE.WebGLRenderer({
      antialias: true,
      alpha: true,
      powerPreference: "high-performance",
      preserveDrawingBuffer: false
    });
    renderer.setSize(window.innerWidth, window.innerHeight);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    renderer.shadowMap.enabled = true;
    renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1;
    rendererRef.current = renderer;

    if (mount && !mount.contains(renderer.domElement)) {
      mount.appendChild(renderer.domElement);
    }

    const controls = new OrbitControls(camera, renderer.domElement);
    controls.enableDamping = true;
    controls.dampingFactor = 0.05;
    controls.maxPolarAngle = Math.PI / 2;
    controls.minDistance = 5;
    controls.maxDistance = 30;
    controlsRef.current = controls;

    const ambientLight = new THREE.AmbientLight(0xffffff, 0.6);
    scene.add(ambientLight);

    const directionalLight = new THREE.DirectionalLight(0x00b4d8, 1);
    directionalLight.position.set(10, 20, 5);
    directionalLight.castShadow = true;
    directionalLight.shadow.mapSize.width = 2048;
    directionalLight.shadow.mapSize.height = 2048;
    scene.add(directionalLight);

    const pointLight = new THREE.PointLight(0xff00ff, 2, 50);
    pointLight.position.set(-10, 10, -10);
    scene.add(pointLight);

    const composer = new EffectComposer(renderer);
    const renderPass = new RenderPass(scene, camera);
    composer.addPass(renderPass);

    const bloomPass = new UnrealBloomPass(
      new THREE.Vector2(window.innerWidth, window.innerHeight),
      0.5,
      0.4,
      0.85
    );
    composer.addPass(bloomPass);
    composerRef.current = composer;

    const floatingObjects = createFloatingProducts(scene);
    const serviceOrbs = createServiceOrbs(scene);
    const avatar = createBrandAvatar(scene);

    const starGeometry = new THREE.BufferGeometry();
    const starCount = 2000;
    const starPositions = new Float32Array(starCount * 3);

    for(let i = 0; i < starCount * 3; i++) {
      starPositions[i] = (Math.random() - 0.5) * 2000;
    }

    starGeometry.setAttribute('position', new THREE.BufferAttribute(starPositions, 3));

    const starMaterial = new THREE.PointsMaterial({
      color: 0xffffff,
      size: 0.7,
      transparent: true
    });

    const stars = new THREE.Points(starGeometry, starMaterial);
    scene.add(stars);

    const animate = () => {
      animationIdRef.current = requestAnimationFrame(animate);

      floatingObjects.forEach((obj, index) => {
        if (obj.rotation) obj.rotation.y += 0.005;
        obj.position.y = Math.sin(Date.now() * 0.001 + index) * 0.3;
      });

      serviceOrbs.forEach((orb, index) => {
        const angle = Date.now() * 0.001 + index;
        const radius = 8 + Math.sin(angle * 0.5) * 2;
        orb.position.x = Math.cos(angle) * radius;
        orb.position.z = Math.sin(angle) * radius;
      });

      if (avatar) {
        avatar.rotation.y += 0.01;
        avatar.position.y = Math.sin(Date.now() * 0.002) * 0.2;
      }

      switch(activeSection) {
        case 'products':
          camera.position.lerp(new THREE.Vector3(0, 3, 10), 0.05);
          break;
        case 'services':
          camera.position.lerp(new THREE.Vector3(10, 5, 0), 0.05);
          break;
        default:
          camera.position.lerp(new THREE.Vector3(0, 5, 15), 0.05);
      }

      controls.update();
      composer.render();
    };

    animate();

    const handleResize = () => {
      camera.aspect = window.innerWidth / window.innerHeight;
      camera.updateProjectionMatrix();
      renderer.setSize(window.innerWidth, window.innerHeight);
      composer.setSize(window.innerWidth, window.innerHeight);
    };

    window.addEventListener('resize', handleResize);

    return () => {
      window.removeEventListener('resize', handleResize);
      cancelAnimationFrame(animationIdRef.current);
      if (mount && renderer.domElement && renderer.domElement.parentNode) {
        try { renderer.domElement.parentNode.removeChild(renderer.domElement); } catch (e) {}
      }
      scene.traverse((object) => {
        if (object.geometry) object.geometry.dispose();
        if (object.material) {
          if (Array.isArray(object.material)) {
            object.material.forEach(material => material.dispose && material.dispose());
          } else {
            object.material.dispose && object.material.dispose();
          }
        }
      });
      renderer.dispose && renderer.dispose();
    };
  }, [activeSection]);

  return <div ref={mountRef} className="three-scene" style={{width:'100%',height:'100%'}}/>;
};

export default ThreeScene;
