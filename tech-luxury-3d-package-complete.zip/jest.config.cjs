module.exports = {
  testEnvironment: 'jsdom',
  transform: {}
};
