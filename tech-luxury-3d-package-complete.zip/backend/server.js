const express = require('express');
const cors = require('cors');
const app = express();
app.use(cors());
app.use(express.json());

const products = [
  { id: 1, name: 'UltraPhone X Pro', price: 1299 },
  { id: 2, name: 'Quantum Laptop Pro', price: 2499 }
];

const services = [
  { id: 1, name: 'Full-Stack Web Development', price: 1299 },
  { id: 2, name: 'AI & Machine Learning', price: 2499 }
];

app.get('/health', (req, res) => res.json({ status: 'ok' }));
app.get('/products', (req, res) => res.json(products));
app.get('/services', (req, res) => res.json(services));
app.post('/order', (req, res) => {
  const { items } = req.body;
  // In production, persist to DB & process payment
  return res.json({ orderId: Date.now(), items });
});

const PORT = process.env.PORT || 4000;
app.listen(PORT, () => console.log('API running on', PORT));
